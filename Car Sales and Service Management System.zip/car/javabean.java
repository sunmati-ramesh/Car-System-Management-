package car;
public class javabean {
    private String Carsdata_carfuel,Carsdata_carcolor,Carsdata_name,Carsdata_type,Carsdata_launchyear,Carsdata_price,carsdata_fueltype;
    
}
