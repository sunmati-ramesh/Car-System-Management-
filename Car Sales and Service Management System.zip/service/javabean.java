package service;
public class javabean {
private String Service_ServiceId,Service_CustomerName,Service_DateOfService,Service_CarBrand,Service_CarNumber,Service_TypeOfService,Service_StoreArea,Service_phone;

public String getService_ServiceId() {
return Service_ServiceId;
}

public void setService_ServiceId(String service_ServiceId) {
Service_ServiceId = service_ServiceId;
}

public String getService_CustomerName() {
return Service_CustomerName;
}

public void setService_CustomerName(String service_CustomerName) {
Service_CustomerName = service_CustomerName;
}

public String getService_DateOfService() {
return Service_DateOfService;
}

public void setService_DateOfService(String service_DateOfService) {
Service_DateOfService = service_DateOfService;
}

public String getService_CarBrand() {
return Service_CarBrand;
}

public void setService_CarBrand(String service_CarBrand) {
Service_CarBrand = service_CarBrand;
}

public String getService_CarNumber() {
return Service_CarNumber;
}

public void setService_CarNumber(String service_CarNumber) {
Service_CarNumber = service_CarNumber;
}

public String getService_TypeOfService() {
return Service_TypeOfService;
}

public void setService_TypeOfService(String service_TypeOfService) {
Service_TypeOfService = service_TypeOfService;
}

public String getService_StoreArea() {
return Service_StoreArea;
}

public void setService_StoreArea(String service_StoreArea) {
Service_StoreArea = service_StoreArea;
}

public String getService_phone() {
return Service_phone;
}

public void setService_phone(String service_phone) {
Service_phone = service_phone;
}
}
