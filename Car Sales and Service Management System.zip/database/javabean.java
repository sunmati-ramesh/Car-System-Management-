package database;
public class javabean {
private String Users_userID,Users_EmailID,Users_UserName,Users_Password,Users_DateOfBirth,Users_Age,Users_Gender,Users_PhoneNumber,Users_Address,Users_DrivingKnown,Users_LicenseNumber;
public String getUsers_EmailID() {
return Users_EmailID;
}

public void setUsers_EmailID(String users_EmailID) {
Users_EmailID = users_EmailID;
}

public String getUsers_UserName() {
return Users_UserName;
}

public void setUsers_UserName(String users_UserName) {
Users_UserName = users_UserName;
}

public String getUsers_Password() {
return Users_Password;
}

public void setUsers_Password(String users_Password) {
Users_Password = users_Password;
}

public String getUsers_Age() {
return Users_Age;
}

public void setUsers_Age(String users_Age) {
Users_Age = users_Age;
}

public String getUsers_Gender() {
return Users_Gender;
}

public void setUsers_Gender(String users_Gender) {
Users_Gender = users_Gender;
}

public String getUsers_PhoneNumber() {
return Users_PhoneNumber;
}

public void setUsers_PhoneNumber(String users_PhoneNumber) {
Users_PhoneNumber = users_PhoneNumber;
}

public String getUsers_Address() {
return Users_Address;
}

public void setUsers_Address(String users_Address) {
Users_Address = users_Address;
}

public String getUsers_DrivingKnown() {
return Users_DrivingKnown;
}

public void setUsers_DrivingKnown(String users_DrivingKnown) {
Users_DrivingKnown = users_DrivingKnown;
}

public String getUsers_LicenseNumber() {
return Users_LicenseNumber;
}

public void setUsers_LicenseNumber(String users_LicenseNumber) {
Users_LicenseNumber = users_LicenseNumber;
}

public String getUsers_DateOfBirth() {
return Users_DateOfBirth;
}

public void setUsers_DateOfBirth(String users_DateOfBirth) {
Users_DateOfBirth = users_DateOfBirth;
}

public String getUsers_userID() {
return Users_userID;
}

public void setUsers_userID(String users_userID) {
Users_userID = users_userID;
}
}